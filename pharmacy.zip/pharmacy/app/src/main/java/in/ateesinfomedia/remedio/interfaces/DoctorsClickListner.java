package in.ateesinfomedia.remedio.interfaces;

import android.view.View;

public interface DoctorsClickListner {
    public void itemClicked(int position,View view,View view1,Object o);
}
