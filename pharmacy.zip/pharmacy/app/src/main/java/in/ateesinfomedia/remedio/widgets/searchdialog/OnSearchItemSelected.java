package in.ateesinfomedia.remedio.widgets.searchdialog;



/**
 * Created by ajithvgiri on 06/11/17.
 */

public interface OnSearchItemSelected {
    void onClick(int position, SearchListItem searchListItem);
}
