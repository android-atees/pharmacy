package in.ateesinfomedia.remedio.interfaces;

public interface OfferCategoryClickListner {
    void titleSelected(String name, int position);
}
