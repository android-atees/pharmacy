package in.ateesinfomedia.remedio.interfaces;

public interface AdapterClickListner {

    public void itemClicked(int position,Object object);
}
